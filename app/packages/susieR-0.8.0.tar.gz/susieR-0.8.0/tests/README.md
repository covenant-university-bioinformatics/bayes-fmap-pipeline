To run unit tests,

```r
devtools::test()
```
