library(testthat)
library(susieR)

test_check("susieR")
